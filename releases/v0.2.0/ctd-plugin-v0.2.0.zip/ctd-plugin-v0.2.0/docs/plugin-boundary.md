# Plugin Boundary

The CTD plugin preview is a skeleton for future packaging.

It may help Codex:

- detect a project kit;
- recommend a minimal-confirmation bootstrap;
- validate local registry files;
- render TaskCards;
- parse ShortReports;
- update local status;
- create handoff files.

It must not claim to:

- bypass Codex permissions;
- silently control other conversations;
- guarantee thread tools in every conversation;
- perform high-risk actions without explicit user confirmation.

Until a formal plugin manifest and verified install surface exist, the project kit remains the default install path.
