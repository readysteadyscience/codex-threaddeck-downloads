# 项目内 ThreadDeck 说明

本目录表示当前项目已经接入 ThreadDeck 总控/分控工作流。

ThreadDeck 的作用：

```text
一个具备 thread tools 的 Codex 主控窗口
  -> 调度用户指定的 worker 窗口
  -> 读取 worker 回复
  -> 汇总关键证据和下一步
```

## 当前项目使用方式

安装后照常使用 Codex。需要多窗口协作、worker、调度、状态检查或 handoff 时，让 Codex 读取本目录并按 ThreadDeck 规则处理。

常用入口：

1. 使用 `thread-registry.yml` 识别当前主控和 worker。
2. 使用 `controller-bootstrap.zh-CN.md` 探测主控能力。
3. 新增 worker 时使用 `add-worker-window.zh-CN.md`。

如果自动 bootstrap 不可用，Codex 可以读取 `activation.zh-CN.md` 作为 internal/debug fallback。

`CTD` 是 `Codex ThreadDeck` 的简称。

Codex 应读取 `activation.zh-CN.md` 并显示手动恢复菜单。

## 重要规则

- 只有具备 thread tools 的对话可以作为主控。
- 不要假装拥有 thread tools。
- 不要向未指定 worker 发送消息。
- 新 worker 必须先经过无副作用测试。
- 高风险动作必须先请求用户确认。
- 每次调度后必须读取 worker 回复并汇总证据。
