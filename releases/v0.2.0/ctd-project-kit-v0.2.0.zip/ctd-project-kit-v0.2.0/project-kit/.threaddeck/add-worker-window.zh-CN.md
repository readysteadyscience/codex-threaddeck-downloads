# 项目内新增 Worker Prompt

把下面内容复制给当前 ThreadDeck 主控窗口。

```text
我要给当前项目新增一个 ThreadDeck worker。

新 worker 角色：
[填写角色名]

职责：
[填写职责]

请先读取：

- .threaddeck/thread-registry.yml

然后判断：

- 是否已有同名 worker
- 是否已有职责重叠 worker
- 是否有旧窗口可以复用
- 是否需要新建窗口

不要立即创建窗口。
不要立即发送消息。

请先输出推荐方案，包括：

- 推荐 worker 标题
- 推荐职责边界
- registry 更新内容
- 安全测试消息
- 需要我确认的下一步

只有我确认后，才可以创建或发送 worker 启动消息。
```
