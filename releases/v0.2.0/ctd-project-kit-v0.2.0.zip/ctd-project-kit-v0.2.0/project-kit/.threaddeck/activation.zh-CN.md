# ThreadDeck 手动恢复菜单

`Launch CTD` 是 legacy/manual fallback，用于排障、手动恢复，或当前环境缺少插件、hook、默认 bootstrap 支持时打开项目内菜单。它不是新用户主流程。

```text
Launch CTD
```

`CTD` 是 `Codex ThreadDeck` 的简称。

正常情况下，项目安装后用户应照常使用 Codex；当用户要求协作、worker、调度、状态检查或 handoff 时，再按 ThreadDeck 规则提供帮助。
ThreadDeck 应先按任务选择最小执行面：当前对话、Codex 原生 subagent、长期可见 worker，或手动 TaskCard / Handoff。

当用户输入该话术时，第一步只显示语言选择：

```text
ThreadDeck / CTD

Please choose a language:

1. 中文
2. English
```

用户选择语言后，后续所有回复、菜单、主控标题、worker 标题、registry 中的推荐 title，都必须使用用户选择的语言。

中文命名示例：

```text
⇄ 项目主控
↳ 研究
↳ 验证
↳ UI
↳ 文档
↳ 发布
```

English naming examples:

```text
⇄ Project Controller
↳ Research
↳ Verification
↳ UI
↳ Docs
↳ Release
```

这些只是可选命名，不代表默认 worker 集合；新任务优先选择最小合适执行面。

兼容说明：旧项目里 worker 可能仍使用 `⇄` 前缀。新建或重命名时应使用 `↳`，迁移旧窗口前先确认它不是主控。

如果用户选择中文，显示：

```text
ThreadDeck 已启动。请选择你要做的事：

1. 新项目接入
2. 老项目改造
3. 启动主控窗口
4. 新增 worker 窗口
5. 发现 worker
6. 安全测试
7. 派发真实任务
8. 检查当前项目 ThreadDeck 状态

请回复数字，或直接说你的目标。
```

If the user chooses English, show:

```text
ThreadDeck is ready. Choose what you want to do:

1. Set up a new project
2. Retrofit an existing project
3. Start the controller conversation
4. Add a worker conversation
5. Discover workers
6. Run a safe test
7. Dispatch a real task
8. Check current ThreadDeck status

Reply with a number, or describe your goal.
```

在用户选择前：

```text
不要发送消息给其他窗口
不要创建窗口
不要修改文件
不要执行命令
不要假装有 thread tools
```

选项对应：

```text
1 -> 新项目接入流程
2 -> 老项目改造流程
3 -> 读取 controller-bootstrap.zh-CN.md
4 -> 读取 add-worker-window.zh-CN.md
5 -> worker discovery
6 -> safe test dispatch
7 -> task handoff
8 -> 只读检查 .threaddeck 和 AGENTS.md
```
