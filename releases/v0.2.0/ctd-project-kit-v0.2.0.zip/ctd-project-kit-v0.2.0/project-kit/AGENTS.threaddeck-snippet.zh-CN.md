## ThreadDeck 总控/分控规则

本项目使用 ThreadDeck 管理多 Codex 对话协作。

项目内 ThreadDeck 配置位于：

```text
.threaddeck/
```

如果用户要求“建立总控/分控”“新增 worker”“调度其他窗口”“检查 ThreadDeck 状态”，先读取：

1. `.threaddeck/README.zh-CN.md`
2. `.threaddeck/thread-registry.yml`
3. `.threaddeck/controller-bootstrap.zh-CN.md`
4. `.threaddeck/add-worker-window.zh-CN.md`

`.threaddeck/activation.zh-CN.md` 只作为 internal/debug fallback，用于排障、手动恢复，或当前环境缺少插件、hook、默认 bootstrap 支持时打开项目内菜单。

`CTD` 是 `Codex ThreadDeck` 的简称。

当需要手动恢复菜单时，先读取：

```text
.threaddeck/activation.zh-CN.md
```

然后显示 ThreadDeck 手动恢复菜单。用户选择前，不要创建窗口、发送消息、修改文件或执行命令。

规则：

- 只有具备 thread tools 的对话可以作为主控。
- 不要假装拥有 thread tools。
- 正常项目协作不要求用户输入或记忆任何口令；手动恢复菜单只用于 internal/debug fallback。
- 手动 fallback 菜单必须先让用户选择语言：`1. 中文` / `2. English`。
- 用户选择语言后，后续回复、菜单、主控标题、worker 标题、registry 推荐 title 都使用该语言。
- 不要向未被用户指定的 worker 发送消息。
- 新 worker 必须先经过无副作用测试。
- 如果 `set_thread_title` 可用，主控应自动加 `⇄` 前缀、测试通过的 worker 应自动加 `↳` 前缀，并按用户选择语言命名。
- 如果 `set_thread_pinned` 可用，正式主控应自动置顶；不可用时提示用户手动置顶。
- 老项目改造时，默认优先复用并改造已有可见对话窗口，不新建重复 worker。只有旧窗口不可见、无法读取/发送、职责确实缺失，且用户确认后，才新建 worker。
- 当主控和 worker 已创建或复用、完成安全测试、registry 已更新且可读时，必须明确告诉用户 ThreadDeck 已经搭建完成。随后提醒用户：之后只需要在主控窗口正常对话；可以继续告诉主控每个分控窗口分别负责什么；主控会按这些职责区分任务并调度 worker。
- 发布、部署、上传、删除、账号、凭证、证书、签名、公证、支付、生产环境、客户交付等高风险动作必须先请求用户确认。
- 每次调度后，主控必须读取 worker 回复，并向用户汇总关键证据。
