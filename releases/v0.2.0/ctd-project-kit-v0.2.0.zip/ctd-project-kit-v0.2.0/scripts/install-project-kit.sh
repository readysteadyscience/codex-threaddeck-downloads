#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage:
  scripts/install-project-kit.sh /path/to/target-project

Installs the ThreadDeck project kit into a target project:
  - copies project-kit/.threaddeck/ to TARGET/.threaddeck/
  - creates or updates TARGET/AGENTS.md with a ThreadDeck entry

The script refuses to overwrite an existing TARGET/.threaddeck directory.
Move it aside first if you want a clean reinstall.
EOF
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

if [[ $# -ne 1 ]]; then
  usage >&2
  exit 2
fi

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
repo_root="$(cd "$script_dir/.." && pwd)"
target_root="$1"

if [[ ! -d "$target_root" ]]; then
  echo "Target project does not exist: $target_root" >&2
  exit 1
fi

target_root="$(cd "$target_root" && pwd)"
kit_dir="$repo_root/project-kit"
threaddeck_source="$kit_dir/.threaddeck"
snippet="$kit_dir/AGENTS.threaddeck-snippet.zh-CN.md"
target_threaddeck="$target_root/.threaddeck"
target_agents="$target_root/AGENTS.md"

if [[ ! -d "$threaddeck_source" ]]; then
  echo "Missing project kit source: $threaddeck_source" >&2
  exit 1
fi

if [[ ! -f "$snippet" ]]; then
  echo "Missing AGENTS snippet: $snippet" >&2
  exit 1
fi

if [[ -e "$target_threaddeck" ]]; then
  echo "Refusing to overwrite existing $target_threaddeck" >&2
  echo "Move it aside or merge manually, then rerun this script." >&2
  exit 1
fi

cp -R "$threaddeck_source" "$target_threaddeck"

if [[ ! -f "$target_agents" ]]; then
  {
    echo "# AGENTS.md"
    echo
    cat "$snippet"
  } > "$target_agents"
  agents_action="created"
elif grep -q "ThreadDeck 总控/分控规则" "$target_agents"; then
  agents_action="already contains ThreadDeck rules"
else
  {
    echo
    cat "$snippet"
  } >> "$target_agents"
  agents_action="updated"
fi

cat <<EOF
ThreadDeck project kit installed.

Target:
  $target_root

Installed:
  $target_threaddeck

AGENTS.md:
  $agents_action

Next steps:
  1. Open the target project in Codex.
  2. Continue using Codex normally.
  3. Ask for ThreadDeck collaboration, workers, dispatch, status, or handoff when needed.
  4. If automatic bootstrap is unavailable, Codex can read .threaddeck/activation.zh-CN.md for internal/debug recovery.

Note:
  ThreadDeck does not keep the full GitHub repository inside your project.
  It installs AGENTS.md plus the hidden .threaddeck/ configuration directory.
  On macOS Finder, press Command+Shift+. to show hidden folders.
EOF
