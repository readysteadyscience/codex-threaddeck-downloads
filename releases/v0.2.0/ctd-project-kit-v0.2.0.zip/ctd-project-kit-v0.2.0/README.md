# CTD Project Kit v0.2.0

This package installs Codex ThreadDeck project rules into a target project.

It contains:

- `scripts/install-project-kit.sh`
- `project-kit/AGENTS.threaddeck-snippet.zh-CN.md`
- `project-kit/.threaddeck/`
- selected public-safe schemas and examples under `templates/`
- Codex install instructions under `docs/CODEX_INSTALL.md`

## Install

```bash
scripts/install-project-kit.sh /absolute/path/to/target-project
```

The installer creates or updates `AGENTS.md` and installs `.threaddeck/`.

After installation, keep using Codex normally. CTD lets Codex detect the project setup, inspect collaboration state, and recommend a minimal-confirmation bootstrap when controller and worker coordination would help.

## Boundary

This package is not a source checkout and does not include Git history.
