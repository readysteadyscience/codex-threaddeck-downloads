# ThreadDeck Codex Install Instructions

This file is written for Codex. Follow it when a user asks you to install ThreadDeck into the current project from a GitHub repository.

## Goal

Install the ThreadDeck project kit into the project that is currently open in Codex, then let the user continue normal Codex work with ThreadDeck collaboration rules available.

`CTD` means `Codex ThreadDeck`.

## Required Inputs

The user should provide:

```text
ThreadDeck GitHub repository URL
Target project = the current Codex project
```

If the current working directory is not clearly the target project root, stop and ask the user to open the correct project first.

## Install Steps

1. Confirm the current working directory is the target project root.
2. Clone the ThreadDeck repository into a temporary directory outside the target project.
3. From the cloned ThreadDeck repository, run:

```bash
scripts/install-project-kit.sh /absolute/path/to/target-project
```

4. Do not overwrite an existing target `.threaddeck/` directory. If it already exists, stop and report that manual merge is required.
5. Verify these files now exist in the target project:

```text
AGENTS.md
.threaddeck/README.zh-CN.md
.threaddeck/activation.zh-CN.md
.threaddeck/thread-registry.yml
.threaddeck/controller-bootstrap.zh-CN.md
.threaddeck/add-worker-window.zh-CN.md
```

6. Read the installed `.threaddeck/README.zh-CN.md` and `.threaddeck/thread-registry.yml`.
7. Tell the user installation is complete and normal Codex work can continue. If thread tools are available, ThreadDeck can guide controller/worker bootstrap when the user asks for collaboration, workers, dispatch, or project status.
8. Treat `.threaddeck/activation.zh-CN.md` as an internal/debug fallback for troubleshooting or environments without plugin/hook/default bootstrap support. Do not present a command phrase as the normal user-facing entrypoint.

## Optional Local Verification

After installation, these helper entrypoints can verify the source kit or produce project handoff artifacts. They do not create Codex threads or perform real cross-thread dispatch.

```bash
node scripts/validate-thread-registry.mjs --input project-kit/.threaddeck/thread-registry.yml
node scripts/render-task-card.mjs --input templates/task-card.example.json --output /tmp/task-card.md
node scripts/parse-short-report.mjs --input templates/short-report.example.zh-CN.txt --output /tmp/short-report.json
node scripts/update-status-board.mjs --report /tmp/short-report.json --board project-kit/.threaddeck/status-board.json --output /tmp/status-board.json --dry-run
node scripts/create-handoff.mjs --project example-project --old old-thread --summary "Handoff summary." --currentState "Current state." --markdown /tmp/handoff.md --json /tmp/handoff.json
```

## Safety Rules

- Do not install into the ThreadDeck repository itself unless the user explicitly says that is the target project.
- Do not overwrite `.threaddeck/`.
- Do not create, message, rename, pin, archive, or otherwise operate on Codex threads during installation.
- Do not claim cross-thread dispatch is available unless the current conversation actually has thread tools.
- Real dispatch still requires thread tools such as `list_threads`, `read_thread`, `send_message_to_thread`, and optionally `create_thread`.

## Success Response

After installation and verification, respond with:

```text
ThreadDeck has been installed into the current project.
The full GitHub repository was only used as the source kit; it does not need to stay inside the target project.
The target project should contain AGENTS.md and a hidden .threaddeck/ directory.
On macOS Finder, press Command+Shift+. if .threaddeck/ is not visible.
Continue using Codex normally. ThreadDeck rules are now available for project collaboration.
If automatic bootstrap is unavailable, Codex can use the installed .threaddeck files to offer the smallest manual troubleshooting path.
```
