<p align="center">
  <img src="media/threaddeck-workbench.png" alt="ThreadDeck Codex workbench showing one controller conversation dispatching work to running worker conversations" width="1120">
</p>

<h1 align="center">ThreadDeck</h1>

<p align="center">
  <strong>Turn one Codex conversation into a live dispatch desk for the other Codex conversations you choose.</strong>
</p>

<p align="center">
  <a href="README.md">English</a>
  ·
  <a href="README.zh-CN.md">简体中文</a>
  <br>
  <a href="#quick-start">Quick Start</a>
  ·
  <a href="#what-it-does">What It Does</a>
  ·
  <a href="#existing-projects">Existing Projects</a>
  ·
  <a href="#safety-model">Safety</a>
</p>

<p align="center">
  <img alt="Status" src="https://img.shields.io/badge/status-v0.1%20workflow%20kit-2f6fed">
  <img alt="License" src="https://img.shields.io/badge/license-MIT-172033">
  <img alt="Built for Codex App" src="https://img.shields.io/badge/built%20for-Codex%20App-495269">
  <img alt="No daemon" src="https://img.shields.io/badge/no-daemon%20required-12965d">
  <img alt="GitHub Repo stars" src="https://img.shields.io/github/stars/readysteadyscience/codex-threaddeck?style=social">
</p>

ThreadDeck is a Codex execution router and workflow kit for real coordination. After installation, you keep talking to Codex normally. ThreadDeck treats ordinary prompts as routable CTD intent, inspects the project and the task, then chooses the smallest useful execution surface: the current conversation, Codex native subagents inside the task, visible long-running worker conversations, or manual TaskCards when tools are missing.

It is not another dashboard. It is a small project kit that makes Codex itself behave like a project control room.

## Why This Exists

Long-running Codex projects tend to become one giant conversation: planning, implementation, tests, release notes, debugging, and random context all mixed together. That works until it gets heavy.

ThreadDeck gives Codex a cleaner routing model:

```text
You
  -> normal Codex prompt
       -> CTD intent compiler creates a routing envelope
       -> single conversation for small tasks
       -> Codex native subagents for bounded multi-part tasks
       -> visible worker conversations for persistent roles
       -> manual TaskCards / ShortReports when tools are missing
  -> compact evidence returns to the controller
```

The controller stays focused on intent, routing, review, and final decisions. Visible worker conversations are not a fixed default set; they are created or reused only when a task needs persistent role context. The controller may use Codex native subagents for bounded local work, and each worker can use Codex native subagents inside its own bounded task when that capability is available.

ThreadDeck also includes a controller drift guard. Before a controller edits files, runs tests/builds/installers, or starts a multi-step fix, it should check whether an active `↳` worker already owns that domain. If a matching worker exists, the controller dispatches a bounded TaskCard instead of absorbing the work. If it self-executes anyway, it must state the delegation check and the reason.

ThreadDeck also manages worker lifecycle. If no suitable persistent worker exists, it should create or select the smallest necessary worker when the current Codex thread tools allow it. If a suitable worker exists but its context is too long, stale, blocked beyond recovery, or role-drifted, ThreadDeck should create a fresh replacement from a compact Handoff instead of forking the old thread. The replacement receives continuity state, not transcript history: current decisions, evidence paths, open tasks, risk boundaries, and the first next step. Replaced, completed, legacy, or unused workers should be archived after a safe checkpoint so the project sidebar stays clean. Archive is reversible; deleting worker history is not part of normal CTD cleanup.

For history retention without focus, ThreadDeck uses a user-level hidden CTD Home. The default location is `~/Documents/.Codex-ThreadDeck/`. Full history references, future history-vault indexes, package caches, and update metadata can live there, while each project keeps only lightweight `.threaddeck/` pointers and continuity Handoffs. A replacement worker reads the Handoff, not the full archived transcript. Later, if a task needs clues from old work, the controller can retrieve the local history index read-only and summarize only the relevant evidence into the current conversation.

## Quick Start

Open the project you want to enable in Codex App, then copy this prompt into Codex. GitHub shows a copy button on the code block.

```text
Codex, install Codex ThreadDeck into the current project.

Repository:
https://github.com/readysteadyscience/codex-threaddeck

Clone the repository into a temporary location, read CODEX_INSTALL.md, and follow the Codex-assisted install flow exactly.
After installation, keep working normally in this Codex project. ThreadDeck should detect the project kit, remind me of the controller/worker collaboration mode when useful, and fall back to manual bootstrap only if my Codex environment does not expose enough thread tools.
```

After Codex reports that installation is complete, use Codex normally. ThreadDeck is a project collaboration mode, not an extra startup ceremony. If plugin, hook, or thread-tool support is unavailable, Codex should detect that, explain the missing capability, and offer the smallest manual bootstrap or troubleshooting path from the installed `.threaddeck/` files.

## What It Does

ThreadDeck helps a tool-enabled Codex controller conversation:

- compile normal prompts into CTD routing envelopes without requiring a startup phrase;
- decide whether a task should stay in the current conversation, use Codex native subagents, use visible worker conversations, or fall back to manual TaskCards;
- set up a new controller and only the worker layout that the task actually needs;
- retrofit an existing project by reusing visible old conversations instead of creating duplicates;
- rename active managed conversations with visible `⇄` controller and `↳` worker prefixes when title tools are available;
- pin the controller conversation when pinning tools are available;
- send harmless safety probes before real dispatch;
- send real task handoffs only to user-selected worker conversations;
- read worker replies back into the controller;
- keep a local `.threaddeck/thread-registry.yml` so roles, status, and evidence stay explicit;
- remind the user, after setup, that normal work continues in the controller conversation.

The `00`, `01`, `02` naming style is optional. ThreadDeck works with whatever conversations the user chooses.

## How It Works

```mermaid
flowchart LR
  U["User"] --> C["Codex controller conversation"]
  C --> X["Execution mode recommendation"]
  C --> R[".threaddeck/thread-registry.yml"]
  X --> S["Single conversation"]
  X --> A["Codex native subagents"]
  X --> W["Visible worker conversations when persistent"]
  X --> M["Manual TaskCards / Handoffs"]
  S --> C
  A --> C
  W --> C
  M --> C
  C --> E["Compact evidence report"]
```

Under the hood, ThreadDeck is just instructions, templates, and safety rules. The real cross-thread part depends on Codex App exposing thread tools in the active conversation.

Required for real dispatch:

- `list_threads`
- `read_thread`
- `send_message_to_thread`

Useful for setup and management:

- `create_thread`
- `set_thread_title`
- `set_thread_pinned`
- `set_thread_archived`

If the current conversation does not have those tools, ThreadDeck must say so clearly. It should never pretend that a message was sent.

## Existing Projects

ThreadDeck is designed for both new projects and old Codex-heavy projects.

For an existing project, the expected behavior is:

1. Inspect the visible Codex conversations for the current project.
2. Reuse and upgrade existing conversations when possible.
3. Avoid creating duplicate workers.
4. Create a new worker when a needed persistent role is missing and thread tools/current policy allow it.
5. Replace an old worker when its context is too long or stale, but do not fork it. Use a compact Handoff with continuity state instead.
6. Archive replaced, completed, legacy, or unused workers after the replacement is active and safe.
7. Run a harmless safety test before treating a worker as active.
8. Update `.threaddeck/thread-registry.yml`.
9. Tell the user the setup is complete and that future work should happen from the controller conversation.

That means ThreadDeck can be adopted without throwing away valuable old project history.

## What Gets Installed

The GitHub repository is only the source kit. It does not need to stay inside your target project.

The install flow places a small project kit into the project you opened in Codex:

```text
your-project/
  AGENTS.md
  .threaddeck/
    README.zh-CN.md
    thread-registry.yml
    activation.zh-CN.md
    controller-bootstrap.zh-CN.md
    add-worker-window.zh-CN.md
    replace-worker-window.zh-CN.md
```

On macOS Finder, press `Command+Shift+.` if you do not see the hidden `.threaddeck/` directory.

Manual installation is also available:

```bash
scripts/install-project-kit.sh /absolute/path/to/your-project
```

## Local CLI Helpers

ThreadDeck includes optional zero-dependency Node helpers for local checks and handoffs. They operate on project files and generated text; they do not create Codex threads or perform cross-thread dispatch by themselves.

```bash
node scripts/validate-thread-registry.mjs --input project-kit/.threaddeck/thread-registry.yml
node scripts/detect-project-state.mjs --root /absolute/path/to/your-project --intent "Describe the current task" --format text
node scripts/recommend-execution-mode.mjs --state /tmp/project-state.json --intent "Describe the current task" --capability multi_agent --format text
node scripts/render-task-card.mjs --input templates/task-card.example.json --output /tmp/task-card.md
node scripts/parse-short-report.mjs --input templates/short-report.example.zh-CN.txt --output /tmp/short-report.json
node scripts/update-status-board.mjs --report /tmp/short-report.json --board project-kit/.threaddeck/status-board.json --output /tmp/status-board.json --dry-run
node scripts/create-handoff.mjs --project example-project --old old-thread --summary "Handoff summary." --currentState "Current state." --markdown /tmp/handoff.md --json /tmp/handoff.json
node scripts/ctd-history-vault.mjs --project example-project --record --thread-id old-thread --thread-title "↳ Implementation" --handoff-id handoff-123 --format text
node scripts/ctd-history-vault.mjs --project example-project --record --thread-id old-thread --thread-title "↳ Implementation" --import-file /tmp/redacted-history.txt --format text
node scripts/ctd-history-vault.mjs --project example-project --find implementation --format json
node scripts/ctd-runtime-doctor.mjs --project-root /absolute/path/to/your-project --format text
node scripts/ctd-hook-installer.mjs --format text
node scripts/ctd-plan-dispatch.mjs --root /absolute/path/to/your-project --format text
```

The runtime doctor is read-only. It checks the local Codex CLI, feature flags, CTD plugin state, plugin files, the Skill default-trigger description, user hook config candidates, and project kit files, then reports whether normal prompts can safely rely on Skill-based CTD routing or need a reviewed hook/runtime installer step. It does not write `~/.codex`, write `.threaddeck/`, install hooks, mutate prompts, create threads, or dispatch messages.

If CTD is installed but an ordinary project prompt does not appear to route through ThreadDeck, check the doctor output first. `Skill default trigger: too narrow` means Codex may only select the CTD Skill when the user explicitly asks for dispatch/control; repair or reinstall the plugin package before expecting default CTD behavior.

The hook installer is also safe by default: without `--apply`, it only prints a plan. If the operator reviews and applies it, it writes only CTD-managed user hook files, records a manifest, and supports `--rollback --apply`. It does not edit Codex `config.toml`, mutate prompts, create threads, or dispatch messages.

The v0.3 preview also includes an advisory auto-route hook script:

```bash
printf '{"prompt":"Implement schema changes and run smoke validation"}' | \
  node scripts/ctd-auto-route-hook.mjs --cwd /absolute/path/to/your-project --event UserPromptSubmit --format text
```

When `.threaddeck/` exists, the hook writes `last-routing-decision.json` and `routing-decisions.jsonl`. It does not rewrite prompts, create Codex threads, or dispatch work by itself.

The routing decision includes an intent compiler envelope and a subagent policy. That policy allows the controller and visible workers to use Codex native subagents for bounded low-risk subtasks when the current Codex environment exposes that capability.

To turn the latest routing decision into a safe controller plan, run:

```bash
node scripts/ctd-plan-dispatch.mjs --root /absolute/path/to/your-project --format text
```

The planner reports whether to reuse a worker, run a safety test, ask the user to create/select a worker, use task-local subagents, or block controller self-execution because an existing worker matches the task. It does not create threads or send messages.

The related templates live in [templates/](templates/), and the scripts live in [scripts/](scripts/).

## After Setup

When ThreadDeck finishes setting up the controller and any needed workers, it should explicitly tell you:

- ThreadDeck setup is complete.
- The controller conversation is the place to continue normal conversation.
- Visible workers are dynamic and task-specific; you do not need Docs/Tests/Implementation/Release windows by default.
- Future tasks can be routed by task type, status, available capabilities, and risk.

From there, you use Codex normally. The difference is that the controller now has a repeatable way to coordinate the other conversations you selected.

## Repository Map

- [CODEX_INSTALL.md](CODEX_INSTALL.md): install instructions written for Codex to read.
- [project-kit/](project-kit/): files copied into a target project.
- [templates/](templates/): controller probes, safe tests, task handoffs, status queries, and migration prompts.
- [docs/](docs/): safety model, live dispatch notes, setup guides, troubleshooting, roadmap, plugin plan, and the [CTD pluginization plan](docs/ctd-pluginization-plan.md).
- [examples/](examples/): sample thread registry and dispatch log.
- [media/](media/): public-safe README and social preview images.
- [RELEASE_CHECKLIST.md](RELEASE_CHECKLIST.md): release gates for docs sync, install smoke, CLI smoke, copy safety, GitHub triage, release notes, and rollback notes.

## Safety Model

Allowed by default:

- status queries;
- progress summaries;
- bounded task handoffs;
- non-destructive checks;
- read-only review;
- compact evidence relay.

Requires explicit user confirmation:

- publish, release, deploy, upload, or external posting;
- destructive file or git operations;
- account, credential, token, certificate, signing, notarization, payment, production, or customer-delivery actions;
- sending the same instruction to multiple workers at once;
- interrupting a worker that is already doing conflicting work.

Read more in [docs/safety-model.md](docs/safety-model.md).

## What This Is Not

ThreadDeck is not:

- an autonomous agent swarm;
- an OpenAI or Codex official feature;
- a tool injection mechanism;
- a way to bypass Codex permissions;
- a guarantee that every Codex conversation has thread tools;
- a place to move secrets between conversations.

ThreadDeck works best when you treat it as a disciplined controller/worker operating pattern inside Codex App.

## FAQ

**Does ThreadDeck require an API key?**

No. The v0.1 kit is documentation, templates, and project instructions. It uses Codex App capabilities when they are available.

**Does it install a background service?**

No. There is no daemon, browser extension, or server in v0.1.

**Can it work if my current Codex conversation has no thread tools?**

It can install the project kit, but it cannot perform real cross-thread dispatch from that conversation. You need a controller conversation where Codex exposes thread tools.

**Can I use my own worker names?**

Yes. The default names are examples. ThreadDeck should respect user-selected conversations and user-defined responsibilities.

**Can it retrofit an old project?**

Yes. The intended behavior is to discover and reuse existing project conversations first, then create only what is missing.

## Roadmap

ThreadDeck starts as an installation-free workflow kit because that is the smallest useful product: copy it into a project, keep using Codex normally, and let Codex coordinate the conversations you choose when the needed thread tools are available.

Future directions:

- v0 project kit: AGENTS.md, `.threaddeck/`, templates, CLI helper scripts, and release gates;
- v1 plugin: bundled Skills that detect adopted projects and recommend controller/worker collaboration without a startup ceremony;
- v1.5 MCP: detect, recommend, render, validate, parse, update status, and create handoffs from project files;
- v2 hooks detection: SessionStart/UserPromptSubmit-style checks when verified lifecycle hooks are available;
- v3 future official lifecycle/app-server: deeper automation only when official surfaces can support it safely.

See [docs/roadmap.md](docs/roadmap.md).

## Contributing

Issues, examples, docs improvements, and real-world setup reports are welcome. If ThreadDeck helps your Codex workflow, a GitHub star makes the project easier for other Codex users to discover.

See [CONTRIBUTING.md](CONTRIBUTING.md).

## Disclaimer

ThreadDeck is an independent community workflow/template project. It is not affiliated with, endorsed by, or sponsored by OpenAI.

Some capabilities depend on what tools your Codex environment exposes.
