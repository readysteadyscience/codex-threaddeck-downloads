# 项目内新增 Worker Prompt

把下面内容复制给当前 ThreadDeck 主控窗口。

```text
我要给当前项目新增一个 ThreadDeck worker。

新 worker 角色：
[填写角色名]

职责：
[填写职责]

请先读取：

- .threaddeck/thread-registry.yml

然后判断：

- 是否已有同名 worker
- 是否已有职责重叠 worker
- 是否有旧窗口可以复用
- 旧窗口是否上下文过长、陈旧、阻塞难恢复或职责漂移
- 是否需要新建窗口

不要立即创建窗口。
不要立即发送消息。

请先输出推荐方案，包括：

- 推荐 worker 标题
- 推荐职责边界
- 如果是接替旧 worker，请说明旧 worker 为什么不适合继续使用
- Handoff 摘要字段：当前状态、关键证据、开放任务、风险边界、第一步
- 是否建议旧 worker 在接替成功后归档
- registry 更新内容
- 安全测试消息
- 需要我确认的下一步

只有我确认后，才可以创建或发送 worker 启动消息。

如果旧 worker 需要接替，不要使用 fork。请让新 worker 从 compact Handoff 启动，只带必要摘要和证据，不继承旧窗口的完整上下文。
```
