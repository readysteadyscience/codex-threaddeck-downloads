# 项目内接替 Worker Prompt

把下面内容复制给当前 ThreadDeck 主控窗口。

```text
我要为当前项目接替一个旧 ThreadDeck worker。

旧 worker：
[填写旧 worker 标题或 thread id]

接替原因：
[context_too_long / role_drift / blocked / stale / manual]

请先读取：

- .threaddeck/thread-registry.yml
- .threaddeck/status-board.json
- .threaddeck/handoffs.json

然后判断：

- 旧 worker 是否确实属于当前项目
- 旧 worker 是否已经上下文过长、陈旧、阻塞难恢复或职责漂移
- 是否已有新的 active/tested worker 可以接替
- 是否需要创建干净的新 worker

不要 fork 旧 worker。
不要把旧 worker 的完整上下文塞进新 worker。
不要追求保留历史记录；目标只是让新 worker 能接上当前工作。
完整历史可以保留在旧 worker 原线程、归档线程或未来 history vault 里，但不要进入新 worker 的上下文焦点。
不要立即归档旧 worker。

请先生成 compact Handoff，包含：

- 旧 worker 的职责边界
- 当前状态
- 关键结论
- 关键证据或 artifact 路径
- 开放任务
- 风险边界
- 新 worker 第一动作
- 旧 worker 历史引用：thread id、标题或归档引用
- 历史焦点策略：do_not_load_full_history_into_replacement

如果 thread tools 可用且当前策略允许，请在我确认后创建或指定接替 worker。
新 worker 只接收 Handoff、TaskCard 和必要证据，不继承旧窗口全文。
新 worker 只需要知道“接下来怎么继续”，不需要知道旧窗口完整发生过什么。
接替 worker 确认并通过无副作用安全测试后，再把旧 worker 标记为 read-only / archive-candidate；如果 `set_thread_archived` 可用，安全归档旧 worker。

归档是可恢复的；不要删除旧 worker。
```
