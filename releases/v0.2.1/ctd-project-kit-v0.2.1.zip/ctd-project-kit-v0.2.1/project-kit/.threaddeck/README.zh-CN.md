# 项目内 ThreadDeck 说明

本目录表示当前项目已经接入 ThreadDeck 总控/分控工作流。

用户级 CTD Home 默认位于：

```text
~/Documents/.Codex-ThreadDeck/
```

项目内 `.threaddeck/history/` 只保存本项目的轻量历史索引和 Handoff 指针；完整历史引用和未来 history vault 索引应放在用户级 CTD Home。接替 worker 只读取 continuity Handoff，不读取旧窗口全文。

ThreadDeck 的作用：

```text
一个具备 thread tools 的 Codex 主控窗口
  -> 调度用户指定的 worker 窗口
  -> 读取 worker 回复
  -> 汇总关键证据和下一步
```

## 当前项目使用方式

安装后照常使用 Codex。需要多窗口协作、worker、调度、状态检查或 handoff 时，让 Codex 读取本目录并按 ThreadDeck 规则处理。

常用入口：

1. 使用 `thread-registry.yml` 识别当前主控和 worker。
2. 使用 `controller-bootstrap.zh-CN.md` 探测主控能力。
3. 新增 worker 时使用 `add-worker-window.zh-CN.md`。
4. worker 上下文过长、陈旧或职责漂移时，使用 `replace-worker-window.zh-CN.md` 生成 compact Handoff 并创建干净接替 worker；不要 fork 旧 worker。

如果自动 bootstrap 不可用，Codex 可以读取 `activation.zh-CN.md` 作为 internal/debug fallback。

`CTD` 是 `Codex ThreadDeck` 的简称。

Codex 应读取 `activation.zh-CN.md` 并显示手动恢复菜单。

## 重要规则

- 只有具备 thread tools 的对话可以作为主控。
- 不要假装拥有 thread tools。
- 不要向未指定 worker 发送消息。
- 新 worker 必须先经过无副作用测试。
- 接替 worker 必须使用 compact Handoff，不要 fork 旧 worker。
- 接替成功后，应归档 replaced、completed、legacy 或 unused worker，保持项目侧栏整洁。
- 高风险动作必须先请求用户确认。
- 每次调度后必须读取 worker 回复并汇总证据。
