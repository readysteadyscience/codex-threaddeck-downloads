# ThreadDeck History Index

这个目录保存当前项目的轻量历史索引、Handoff 指针和旧 worker 引用。

默认规则：

- 不保存 API key、token、cookie、密码、证书或凭证。
- 不把旧 worker 的完整对话全文复制进新 worker。
- 不把完整历史写进公开仓库。
- 接替 worker 只读取 continuity Handoff。
- 完整历史引用或未来 history vault 索引应保存在用户级 CTD Home。

用户级 CTD Home 默认路径：

```text
~/Documents/.Codex-ThreadDeck/
```

常见结构：

```text
~/Documents/.Codex-ThreadDeck/
  history/
    <project-id>/
      handoffs/
      thread-index.json
      artifacts.json
  cache/
  downloads/
  updates/
```

如果用户手动恢复归档窗口，主控可以读取这里的索引和 Handoff，找到旧 thread 引用，再按需回查历史。不要把完整旧历史直接注入 replacement worker。
