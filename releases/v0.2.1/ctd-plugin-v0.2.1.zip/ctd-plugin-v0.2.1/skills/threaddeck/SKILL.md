---
name: codex-thread-dispatch
description: Default ThreadDeck routing for normal Codex project work when CTD is installed or a project mentions ThreadDeck, .threaddeck, or CTD in AGENTS.md. Use for ordinary user prompts, project work, multi-step coding tasks, controller/worker coordination, subagent policy, task routing, task cards, short reports, handoffs, and cross-thread dispatch when thread tools are available.
---

# Codex Thread Dispatch

## Goal

Let this conversation act as the controller thread: the user talks here, and Codex can inspect other Codex threads, choose the correct target, send bounded follow-up prompts, then report back.

This Skill is for local Codex App thread coordination. It does not make other threads autonomous without user-visible routing and safety checks.

The target worker threads are user-selected. Numbered names such as `00`, `01`, or `06` are optional conventions, not requirements.

## Default Intent Compiler

When CTD is installed, treat ordinary user prompts as CTD-routable by default. The user does not need to say "use CTD", "dispatch", or any startup phrase.

For each normal task, compile the user's prompt into a CTD routing envelope before deciding how to act:

```text
normal user prompt
  -> CTD routing envelope
  -> choose the smallest safe execution surface
  -> act locally, use Codex native subagents, dispatch to visible workers, or create manual TaskCards
```

This is an execution interpretation, not permission to bypass Codex tools. It does not rewrite the user prompt, silently create threads, or skip confirmation gates.

The old manual activation phrase is a compatibility, debug, and manual-recovery fallback. Do not make it the main entry point for normal installed-project work.

## Operating Model

```text
User in controller thread
  -> inspect project and task state
  -> choose execution surface
     -> single conversation
     -> Codex native subagents inside the current task
     -> visible worker threads for persistent roles
     -> manual TaskCards / Handoffs when tools are missing
  -> report compact evidence here
```

## Available Thread Actions

Use the current Codex App thread tools when available:

- `list_threads`: find candidate target threads by title, cwd, status, or preview.
- `read_thread`: inspect recent status and turns before sending.
- `send_message_to_thread`: send a follow-up prompt to an existing thread.
- `create_thread`: create a new background thread when no suitable one exists.
- `set_thread_title`: rename the official controller and tested worker threads when the dispatch setup needs clear labels.
- `set_thread_pinned`: pin the official controller thread when it becomes active; pin/unpin other threads only when the user explicitly asks.
- `set_thread_archived`: archive/unarchive threads if the user explicitly asks.

If these tools are not available in the current environment, stop and explain that thread dispatch cannot be performed from this session.

## Project-State Detection

Before recommending a controller/worker bootstrap for a normal user task, inspect the project state when the repository includes ThreadDeck helpers:

```bash
node ../../scripts/detect-project-state.mjs --root . --intent "<current user task>" --format text
```

Use this result to decide whether to continue normal Codex work, recommend installing the project kit, repair an incomplete `.threaddeck/` setup, or ask for minimal confirmation before dispatch. This command is read-only and does not create Codex threads.

Then recommend the smallest execution surface:

```bash
node ../../scripts/recommend-execution-mode.mjs --state /tmp/project-state.json --intent "<current user task>" --capability multi_agent --format text
```

Do not use a fixed default set of Docs/Tests/Implementation/Release workers. For bounded complex tasks, prefer Codex native subagents when available. Create or reuse visible worker threads only for persistent roles, long-running maintenance, old-project migration, or when cross-window context must be preserved. A visible worker may use Codex native subagents inside its own task.

The controller may also use Codex native subagents for its own bounded implementation, research, or verification work. A visible worker receiving a TaskCard may use Codex native subagents inside that worker's task when the TaskCard allows it, subject to bounded scope, max-depth, max-count, and risk gates.

## Controller Drift Guard

Before the controller edits files, runs a build/install, changes project state, or starts a multi-step fix, it must perform a delegation check.

The controller should not gradually turn into the implementation worker during a long session. Its default job is to route, summarize, verify, and decide.

Use this order:

1. If an active or tested `↳` worker already matches the task domain, dispatch a bounded TaskCard to that worker before controller self-execution. The worker may use Codex native subagents inside its own task.
2. If no matching visible worker exists but the task is bounded and low risk, use Codex native subagents in the controller thread.
3. If the task is truly tiny, local, and does not touch durable project state, the controller may self-execute.
4. If the controller self-executes a non-trivial task, it must state the delegation check explicitly: `CTD delegation check: self-execute because ...`.
5. If the controller has already started editing and later discovers a matching worker, stop at the next safe checkpoint, summarize the current evidence, and hand the remaining work to the worker.

When the project has `ctd-plan-dispatch.mjs`, use it as the executable guard. If it returns `delegate_to_existing_worker_before_self_execution`, read the matching worker status and dispatch instead of continuing implementation in the controller.

When `.threaddeck/last-routing-decision.json` exists, read it as advisory evidence of the most recent CTD auto-route hook decision. Do not treat it as permission to create threads or dispatch work; real dispatch still requires available thread tools and the usual confirmation gates.

When available, turn the routing decision into a safe dispatch plan before touching thread tools:

```bash
node ../../scripts/ctd-plan-dispatch.mjs --root . --format text
```

If the plan says `request_user_confirmation_to_create_or_select_workers`, ask the user before creating, renaming, or registering workers. If the plan says `run_safe_test_before_dispatch`, send only the harmless safety test first. If the plan says `prepare_task_card_for_existing_workers`, read the worker status and render a bounded TaskCard before dispatch. When rendering a TaskCard for a visible worker, include `workerMayUseSubagents: true` and a bounded `subagentPlan` when the routing plan allows worker-local Codex native subagents.

## Worker Lifecycle Guard

Visible workers are durable role containers, not disposable per-task tabs. Keep them useful and keep the project sidebar clean.

Use this lifecycle order:

1. If no suitable `↳` worker exists for a persistent role, create or select the smallest necessary new worker when thread tools and current policy allow it. Otherwise produce a manual TaskCard.
2. If a suitable worker exists, read it before dispatching.
3. If that worker's context is too long, stale, blocked beyond recovery, or role-drifted, do not fork it. Forking copies the heavy context into the replacement and defeats the purpose.
4. Create a compact Handoff from the old worker instead: only continuity state, current decisions, evidence paths, open tasks, risk boundaries, and first next step. Do not preserve the old transcript.
5. Preserve a local history reference before archival. Default CTD Home is `~/Documents/.Codex-ThreadDeck/`, or `CTD_HOME` when configured. Project `.threaddeck/history/` is only a lightweight pointer layer.
6. Start a fresh replacement worker from that Handoff and mark it with the `↳` prefix.
7. After the replacement has acknowledged the Handoff and passed any harmless safety test, mark the old worker read-only, archive-candidate, or archived when `set_thread_archived` is available.
8. Archive unused, completed, legacy, or replaced workers promptly after a safe checkpoint and after local history reference is recorded. Archiving is reversible by the user; deleting is not part of normal CTD cleanup.

The controller is the only thread that may connect long history. Replacement workers receive continuity state, not history. The goal is to keep work moving, not to preserve the old context window.

## Routing Rules

Before sending any message:

1. Identify the target thread by at least two signals:
   - thread title;
   - `cwd`;
   - thread id;
   - recent preview/status;
   - user-provided role name.
2. Read the target thread unless the user explicitly supplied a thread id and asked for a simple low-risk status ping.
3. Verify the target thread is appropriate for the task.
4. Keep the dispatch prompt short, scoped, and compatible with the target thread's existing role.
5. Report exactly which thread was messaged: title, thread id, `cwd`, and prompt summary.

If multiple candidates match, ask the user to choose unless one candidate is clearly superior from title plus `cwd`.

## Naming And Hygiene

When the user wants a thread to become an official dispatchable worker, prefer marking it with a visible dispatch prefix:

```text
⇄ <controller thread title>
↳ <worker or specialist thread title>
```

Use the prefix to distinguish the active ThreadDeck controller and active ThreadDeck-managed workers from legacy, duplicate, backup, or migration-only threads.

Recommended hygiene rules:

- Keep only the active controller and active workers unarchived when possible.
- Pin the active controller when `set_thread_pinned` is available.
- Archive legacy, completed, stale, replaced, or backup worker threads after migration or replacement.
- Never dispatch to a legacy thread when an official `↳` thread exists for the same role.
- If the user wants to preserve an old thread's history, have the tool-enabled controller read and migrate compact state into the active controller or a Handoff instead of trying to inject the entire old transcript into a new worker.
- For a candidate target, prefer an official `↳` thread over an unprefixed older thread when title/cwd otherwise overlap.

## Message Types

Allowed by default:

- status query;
- progress summary request;
- task handoff inside the target thread's existing responsibility;
- request to inspect files or run non-destructive checks;
- request to pause and summarize before continuing;
- request to create a plan, research card, or implementation note.
- compact evidence handoff from one worker to another through the controller.

Require explicit user confirmation before sending:

- publish, release, deploy, upload, or external posting;
- deletion, destructive git operations, reset, checkout, or cleanup;
- account, payment, credential, token, signing, notarization, production, customer delivery, or private repository actions;
- any instruction that could conflict with the target thread's current task;
- sending the same instruction to more than one thread;
- changing model or reasoning settings for another thread;
- creating new threads in bulk.

Refuse or narrow:

- hidden or silent control of other threads;
- bulk autonomous task dispatch without status checks;
- instructions that intentionally bypass user approval or project safety rules;
- moving secrets between threads.

## Dispatch Prompt Template

Use this shape unless the user asks for a different format:

```text
来自主控线程的任务交接：

目标：
<one concrete objective>

边界：
- <what to touch>
- <what not to touch>

上下文：
- <minimal relevant context from controller thread>

请先做：
1. 读取当前线程已有上下文和项目入口文件。
2. 判断这项任务是否属于本线程职责。
3. 如果属于，继续执行并在完成后给出状态摘要。
4. 如果不属于或会冲突，先停止并说明原因。
```

## Status Query Template

```text
来自主控线程的状态查询：

请用简短格式汇报当前线程：
- 当前目标
- 进行状态
- 最近完成的事
- 阻塞点
- 下一步建议

不要改文件，除非当前线程原本正在执行的任务已经需要继续。
```

## Workflow

1. Parse the user's controller request.
2. Decide whether to list, read, send, create, or manage a thread.
3. Use `list_threads` when the target thread is not already known.
4. Use `read_thread` before dispatch for non-trivial tasks.
5. Compose the prompt using the smallest necessary context.
6. If the action is high risk or ambiguous, ask for confirmation before sending.
7. Send with `send_message_to_thread` or create a new worker with `create_thread`.
8. Report the result in the controller thread.
9. For important dispatches, suggest or write a local dispatch log if the project has a log location.

For active multi-worker projects, use compact dispatch:

- One short send message.
- One short receive/status report.
- Preserve only the critical evidence: artifact path, version, checksum, test result, blocker, or next owner.
- Avoid long summaries unless the user asks.

## Output Back To User

After dispatch, report:

- target thread title;
- target thread id;
- target `cwd`;
- sent message type;
- one-line prompt summary;
- whether the target was active or idle before sending;
- any follow-up needed.

Keep the report concise. Do not paste a long prompt unless the user asks.

For compact mode, prefer this shape:

```text
Sent: <target title> / <message type>.
Result: <one-line status or callback>.
Next: <next owner or wait state>.
```

## Notes

- This Skill controls Codex threads through available local thread tools; it does not guarantee that the target thread finishes before the controller responds.
- Prefer a small number of well-named worker threads over many ad hoc threads.
- For multi-project work, route by project directory first, title second.
- Treat the controller thread as the source of coordination, not as a place to import every worker thread's full context.
- A controller may act as a lightweight event bus between workers by forwarding compact evidence from one worker to another, as long as the forwarded content is scoped, non-secret, and relevant to the receiving worker's role.
